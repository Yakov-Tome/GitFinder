import React from "react";

function About() {
  return (
    <>
      <h1 className="text-6xl mb-4">GitFinder</h1>
      <p className="mb-4 text-2xl font-light">About</p>
    </>
  );
}

export default About;
